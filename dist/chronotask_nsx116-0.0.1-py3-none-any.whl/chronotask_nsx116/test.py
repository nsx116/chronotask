def write_at_start(global_id, work_started_at):
    files = Files()
    data = load_data(files.data_file)
    tasks = data.get("tasks", [])
    sorted_ids = data.get("sorted_ids", {})
    # Get the task's global ID
    task_id = global_id
    if not tasks:
        print("No tasks available.")
        return
    # Locate the task by its global ID
    task = next((item for item in tasks if item.get("global_id") == task_id), None)
    if not task:
        print(f"Task with ID {task_id} not found.")
        return
    # Get today's date as a string
    today = datetime.now().strftime("%Y-%m-%d")
    # Initialize history for today if it doesn't exist
    if "history" not in task:
        task["history"] = {}
    if today not in task["history"]:
        task["history"][today] = []
    # Add the new work session to the task's history
    task["history"][today].append({
        "work_started_at": work_started_at, 
        "work_stopped_at": None, 
        "minutes": 0,
    })
    # Save the updated data back to the file
    save_data(files.data_file, data)
    print(f"Updated task {task_id} with work session on {today}.")


def write_total_activity_to_task(data_file, global_id, settings):
    data = load_data(data_file)
    tasks = data.get("tasks")  
    sorted_ids = data.get("sorted_ids")
    task_id = str(global_id)
    if tasks:
        for item in tasks:
            if task_id == item.get("global_id"):
                task = item
                break
        if task:
            task["total_work"] += round(settings.work_duration / 60, 1)
            try:
                last_date = max(task["history"].keys())
                last_item = task["history"][last_date][-1]
                now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                last_item["work_stopped_at"] = now
                last_item["minutes"] += round(settings.work_duration / 60, 1)
            except KeyError:
                print(f"No history available for task with ID {task_id}.")
        else:
            print(f"Task with ID {task_id} not found.")
    save_data(data_file, data)


def write_past_minutes_when_quit(global_id, activity_duration):
    files = Files()
    data = load_data(files.data_file)
    tasks = data.get("tasks", [])
    sorted_ids = data.get("sorted_ids", {})
    
    # Get the task's global ID
    task_id = global_id
    
    if not tasks:
        print("No tasks available.")
        return
    
    # Locate the task by its global ID
    task = next((item for item in tasks if item.get("global_id") == task_id), None)
    
    if not task:
        print(f"Task with ID {task_id} not found.")
        return
    
    # Get today's date as a string
    today = datetime.now().strftime("%Y-%m-%d")
    if task:
        task["total_work"] += round(activity_duration / 60, 1)
        try:
            last_date = max(task["history"].keys())
            last_item = task["history"][last_date][-1]
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            last_item["work_stopped_at"] = now
            last_item["minutes"] += round(activity_duration / 60, 1)
        except KeyError:
            print(f"No history available for task with ID {task_id}.")
    else:
        print(f"Task with ID {task_id} not found.")
    save_data(files.data_file, data)
    print(f"Updated task {task_id} with work session on {today}.")
