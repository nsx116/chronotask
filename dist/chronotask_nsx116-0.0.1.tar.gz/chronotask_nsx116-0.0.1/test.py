todos_by_date = {"2024-10-11": {"global_id1": "60", "global_id2": "70", "total_work": "130"},
                 "2024-10-12": {"global_id34": "15", "global_id43": "25"},}


    with open(self.pomodoro_summary, 'a') as f:
        f.write(f"Work stopped at:  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Pomodoros completed: {self.interval_timer.pomodoro_count}\n")
        f.write(f"Total work minutes: {self.interval_timer.total_work_minutes}\n")
        f.write(f"Total rest minutes: {self.interval_timer.total_rest_minutes}\n")
        f.write("------------------------------------\n")
    print(f"Pomodoro summary written to {self.pomodoro_summary}. Exiting...")

todos_by_date[date_str]["todos"].append({
    "text": text, 
    "completed": completed, 
    "time_str": time_str,
    "subtasks": subtasks,
    "tags": translated_tags,
})

def write_summary_to_json(self):
    """Writes Pomodoros, work minutes, and rest minutes to a file."""
    date_str = date.today().strftime("%Y-%m-%d")
    if date_str not in total_work_by_date:
        total_work_by_date[date_str] = {}
    if task not in total_work_by_date[date_str]:
        dailys_by_date[date_str][task] = work_minutes
    elif task in total_work_by_date[date_str]:
        total_work_by_date[date_str][task] += work_minutes
    total_work_by_date[date_str][total_work] = sum(int(value) for key, value in total_work_by_date[date_str].items() if key != "total_work")

